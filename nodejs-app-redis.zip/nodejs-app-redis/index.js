const express = require('express');
const bodyParser = require('body-parser');
const app = express();

const Promise = require('bluebird');
const redis = Promise.promisifyAll(require('redis'));

const port = process.env.PORT || 3000;

app.use(bodyParser.raw({ inflate: false }));

const client = redis.createClient(process.env.REDIS_URL);

app.put('/:key', async(req, res) => {
    await client.setAsync(req.params.key, req.body);
    res.send('OK!');
});

app.get('/:key', async (req, res) => {
    const value = await client.getAsync(req.params.key);
    res.send(value);
});

app.listen(port, () => console.log(`[${new Date()}] Server startup, port = ${port}`));
