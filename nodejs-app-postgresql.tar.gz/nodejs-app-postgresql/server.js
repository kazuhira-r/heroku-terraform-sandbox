const express = require('express');
const pgp = require('pg-promise')

const postgresql = pgp(`${process.env.DATABASE_URL}?ssl=true`);

const port = process.env.PORT || 3000;

app.get('/', async (req, res) => {
    postgresql
        .any('SELECT table_schema,table_name FROM information_schema.tables')
        .then(data => res.send(JSON.stringify(data)));
});

app.listen(port, () => console.log(`[${new Date()}] Server startup, port = ${port}`));
